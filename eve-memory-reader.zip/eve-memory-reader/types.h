#pragma once

typedef unsigned char byte;