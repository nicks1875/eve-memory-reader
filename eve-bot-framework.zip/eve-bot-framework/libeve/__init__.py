KEYMAP = {
    "F1": "inFlightHighSlot1",
    "F2": "inFlightHighSlot2",
    "ALT1": "inFlightMediumSlot1",
    "ALT2": "inFlightMediumSlot2",
}
