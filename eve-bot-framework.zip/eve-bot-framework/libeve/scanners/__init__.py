class Scanner(object):
    def __init__(self):
        pass


class EnemyScanner(Scanner):
    def __init__(self):
        pass


registered_scanners = {"EnemyScanner": EnemyScanner}
